{{- define "krevo.name" -}}
{{- printf "%s-local" .Release.Name | trunc 50 | trimSuffix "-" -}}
{{- end -}}
{{- define "krevo.validate" -}}
{{- $_ := required "clusterId is required" .Values.clusterId -}}
{{- $_ := required "credentials.existingSecret is required" .Values.credentials.existingSecret -}}
{{- if empty .Values.collector.namespaces }}{{ fail "collector.namespaces must explicitly select at least one namespace" }}{{ end -}}
{{- if or (lt (int .Values.retentionDays) 1) (gt (int .Values.retentionDays) 90) }}{{ fail "retentionDays must be between 1 and 90" }}{{ end -}}
{{- end -}}
