# KrevoPilot customer-local storage

Optional customer-operated ClickHouse + OpenTelemetry storage for logs and Kubernetes events.
No SaaS deployment, public endpoint, tracing integration or metrics migration is included.
Existing Kubernetes/Loki workflows remain available. Use agent 2.0.45 / chart 0.1.48 or newer. Existing agents must be upgraded explicitly.

## Install

Requirements: Linux Kubernetes nodes, Helm 3+, a default StorageClass (or explicit
`clickhouse.storageClass`), permission to install the listed RBAC, and a CNI enforcing
NetworkPolicy. Start with 500m CPU / 1Gi RAM requested for ClickHouse (2 CPU / 2Gi
limit), 20Gi database PVC, 1Gi event-buffer PVC and 100m CPU / 128Mi per collector.
These are pilot starting allocations, not measured production sizing guarantees.
Allow sufficient cluster headroom. Windows nodes are unsupported.

1. Choose a dedicated storage namespace and explicitly list application namespaces.
2. In the storage namespace, provision an existing Secret with three independent,
   nonempty keys: `admin-password`, `ingest-password`, `reader-password`. Use your
   secret manager; do not commit credentials or put passwords in Helm command lines.
3. Create `local-values.yaml` (no credentials):

```yaml
clusterId: your-cluster-identifier
credentials:
  existingSecret: krevo-local-credentials
retentionDays: 7
collector:
  namespaces: [your-application-namespace]
  collectNodeLogs: true
networkPolicy:
  readerPodSelector:
    app.kubernetes.io/name: krevopilot-agent
  readerNamespaceSelector:
    matchLabels:
      kubernetes.io/metadata.name: krevopilot-system
```

```sh
helm upgrade --install krevo-storage ./deploy/charts/krevo-local-storage \
  --namespace krevo-storage --create-namespace --values local-values.yaml --wait
```

The dedicated events collector runs one replica with Recreate updates. The optional
node collector uses a DaemonSet, read-only `/var/log/pods`, root file access (not
privileged), and a writable node-local checkpoint/queue directory. The events collector
uses a PVC for its queue. Metadata enrichment reads pod and namespace metadata across
the cluster; event RBAC is restricted to selected namespaces. No Secrets-read RBAC,
workload writes, host networking, ingress or LoadBalancer is installed.

## Connect KrevoPilot

Install the versioned agent chart supplied with this release (0.1.48, image 2.0.45).
Configure its Deployment environment:

```yaml
- name: EXTERNAL_LOG_SOURCE
  value: clickhouse
- name: LOG_STORAGE_MODE
  value: customer_storage
- name: LOGS_ENABLED
  value: "true"
- name: LOGS_MAX_LOOKBACK_MINUTES
  value: "10080"
- name: EXTERNAL_LOG_SOURCE_URL
  value: http://krevo-storage-local-clickhouse.krevo-storage.svc.cluster.local:8123
- name: CLICKHOUSE_USERNAME
  value: krevo_reader
- name: CLICKHOUSE_PASSWORD
  valueFrom:
    secretKeyRef:
      name: krevo-local-reader
      key: reader-password
- name: CLICKHOUSE_CLUSTER_ID
  value: your-cluster-identifier
```

Provision the reader Secret separately in the agent namespace. Give the agent no admin
or ingestion password. Match `CLICKHOUSE_CLUSTER_ID` to the Helm `clusterId`; it is a
local database partition identifier, not a replacement for SaaS tenant authorization.
The NetworkPolicy reader selector must match the actual agent pod labels.

The agent probes SELECT access to the logs table, reports availability, and uses
parameterized, cluster/namespace/pod/container-scoped queries. Observe historical-log
widgets and AI's existing on-demand log tool use that path. Rows, bytes, scan size,
time range and execution time are bounded. Evidence is redacted again before upload.
Previous-container requests still use Kubernetes because the stored schema does not
distinguish previous container instances. An unavailable backend reports unavailable;
the general live-log path may still serve Kubernetes logs and labels its actual source.

## Data lifecycle and privacy

- Default seven-day TTL; supported configuration 1–90 days. Helm upgrades restart
  ClickHouse and apply the new TTL through the initialization SQL. TTL deletion is
  asynchronous; it is not a promise of immediate physical erasure. A retention change
  must be verified with `SHOW CREATE TABLE krevo.otel_logs` after upgrade.
- Database persistence is a PVC. The customer chooses storage provider, region,
  encryption and capacity. PVC size is not a retention guarantee: a high ingestion
  volume can fill it first. Monitor disk space, dropped/refused records, export errors,
  CPU/RAM and query latency. Existing bound PVC resizing is an operator action.
- Bounded persistent collector queues and checkpoints improve recovery. This is
  best-effort, at-least-once telemetry, not an audit log. Queue overflow, prolonged
  outages, node loss or unflushed batches can lose records; event watches can duplicate
  records. Node-local queues do not survive replacement of that node.
- Basic password/token/email patterns are removed from message bodies before storage.
  This is not a complete secret/PII detector. Customer-specific filters must be reviewed
  before collection. Kubernetes event bodies can contain operational identifiers.
- Raw history stays local, but requested redacted snippets pass to KrevoPilot SaaS
  and may reach the configured external AI provider. Existing platform snapshot,
  evidence and command retention policies remain separate. Local storage is not a
  local-only AI processing guarantee.
- NetworkPolicy restricts database ingress where supported by the CNI. In-cluster
  traffic in this pilot chart is not TLS-encrypted; do not expose it publicly. Use an
  approved encrypted service mesh or add TLS before networks requiring transport
  encryption. NetworkPolicy does not substitute for TLS or database authentication.

## Operations, backups and uninstall

Customer: infrastructure, storage costs, credential rotation, backup schedules,
restore exercises and upgrades. KreateRevo: supported configuration and integration.
Single-replica ClickHouse is intentionally a pilot topology, not high availability.
Database outages interrupt ingestion/querying but must not modify customer workloads.
Keep backups in customer-controlled storage with a separately agreed expiry policy;
this package does not schedule backups. Restore into an isolated namespace and validate
schema, row counts, access restrictions and representative queries before cutover.

Review pinned image versions and release notes before upgrades. Export schema/config,
back up the database, upgrade in development, and test TTL and reader/ingest permissions.
Use the chart's resource settings and namespace allowlist to limit collection scope;
there is no hard daily ingestion-byte quota in this pilot version.

`helm uninstall krevo-storage -n krevo-storage` removes collectors and the service;
the StatefulSet database PVC is retained by Kubernetes. The event-queue PVC is a normal
Helm resource and is removed; node checkpoint directories are not removed. Explicitly
inventory and remove database volumes, node directories and backups only after the
customer approves the data-deletion policy. Deleting a namespace can delete retained
PVCs, so do not use namespace deletion as a casual uninstall step.

## Test and current boundaries

Run agent unit tests, frontend tests/build, Helm lint, and
`python scripts/test_local_telemetry.py` against the isolated test installation described
in that script. Tests must not be pointed at a customer namespace.

Application tracing, historical event query UI/AI tools, historical metric dashboards,
arbitrary deleted-pod selection, absolute incident time windows, automatic backups,
production HA and hard ingestion quotas are follow-on work. The current UI requests
logs for a pod still present in its selected snapshot, up to seven days through the historical widget, subject to the agent’s configured
maximum lookback. Events are stored locally
for later correlation while the existing live events continue to power investigations.
